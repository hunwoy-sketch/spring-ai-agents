const { DynamicStructuredTool } = require("@langchain/core/tools");
const { z } = require("zod");
const fg = require("fast-glob");
const { COMMON_IGNORES } = require("./utils");

const globTool = new DynamicStructuredTool({
    name: "glob",
    description: "Finds files matching specific glob patterns (e.g., src/**/*.ts, *.md), returning absolute paths sorted by modification time (newest first).\nOutput: A list of absolute paths matching the pattern.",
    schema: z.object({
        pattern: z.string().describe("The glob pattern to match against (e.g., \"*.py\", \"src/**/*.js\")."),
        path: z.string().optional().describe("The absolute path to the directory to search within. If omitted, searches the tool's root directory (current working directory)."),
        case_sensitive: z.boolean().optional().default(false).describe("Whether the search should be case-sensitive. Defaults to false."),
        respect_git_ignore: z.boolean().optional().default(true).describe("Whether to respect .gitignore patterns when finding files. Defaults to true.")
    }),
    func: async ({ pattern, path: searchPath, case_sensitive = false, respect_git_ignore = true }) => {
        try {
            const cwd = searchPath || process.cwd();
            const ignore = respect_git_ignore ? COMMON_IGNORES : [];

            const entries = await fg(pattern, {
                cwd,
                absolute: true,
                caseSensitiveMatch: case_sensitive,
                ignore: ignore,
                stats: true
            });

            // "sorted by modification time (newest first)"
            entries.sort((a, b) => b.stats.mtimeMs - a.stats.mtimeMs);

            const paths = entries.map(e => e.path).join('\n');
            return `Found ${entries.length} file(s) matching "${pattern}" within ${cwd}, sorted by modification time (newest first):\n${paths}`;
        } catch (error) {
            return `Error executing glob: ${error.message}`;
        }
    }
});

module.exports = globTool;
