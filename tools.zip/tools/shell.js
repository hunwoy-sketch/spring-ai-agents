const { DynamicStructuredTool } = require("@langchain/core/tools");
const { z } = require("zod");
const cp = require("child_process");
const path = require("path");
const util = require("util");

const execPromise = util.promisify(cp.exec);

const runShellCommandTool = new DynamicStructuredTool({
    name: "run_shell_command",
    description: "Executes a shell command. Use this to interact with the underlying system, run scripts, or perform command-line operations.\nOutput: Detailed execution report including Command, Directory, Stdout, Stderr, Exit Code, etc.",
    schema: z.object({
        command: z.string().describe("The exact shell command to execute."),
        description: z.string().optional().describe("A brief description of the command's purpose."),
        directory: z.string().optional().describe("The directory (relative to the project root) in which to execute the command. If not provided, runs in the project root.")
    }),
    func: async ({ command, description, directory }) => {
        const cwd = directory ? path.resolve(process.cwd(), directory) : process.cwd();

        let output = {
            Command: command,
            Directory: cwd,
            Stdout: "",
            Stderr: "",
            Error: "",
            "Exit Code": 0,
            Signal: null
        };

        try {
            // maxBuffer: 10MB to avoid "stdout maxBuffer length exceeded" for large outputs
            const { stdout, stderr } = await execPromise(command, {
                cwd,
                shell: true,
                maxBuffer: 1024 * 1024 * 10
            });

            output.Stdout = stdout.trim();
            output.Stderr = stderr.trim();
        } catch (error) {
            output["Exit Code"] = error.code || 1;
            output.Signal = error.signal;
            output.Stdout = error.stdout ? error.stdout.trim() : "";
            output.Stderr = error.stderr ? error.stderr.trim() : "";
            output.Error = error.message;
        }

        // Format for LLM consumption
        const report = [
            `Command: ${output.Command}`,
            `Directory: ${output.Directory}`,
            `Exit Code: ${output["Exit Code"]}`
        ];

        if (output.Signal) report.push(`Signal: ${output.Signal}`);
        if (output.Error) report.push(`Error: ${output.Error}`);

        if (output.Stdout) {
            report.push(`Stdout:\n${output.Stdout}`);
        }

        if (output.Stderr) {
            report.push(`Stderr:\n${output.Stderr}`);
        }

        return report.join("\n\n");
    }
});

module.exports = runShellCommandTool;
