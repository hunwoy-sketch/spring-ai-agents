const { DynamicStructuredTool } = require("@langchain/core/tools");
const { z } = require("zod");
const fs = require("fs-extra");

const writeFileTool = new DynamicStructuredTool({
    name: "write_file",
    description: "Writes content to a specified file. If the file exists, it will be overwritten. If not, it (and parent directories) will be created.\nOutput: A success message indicating if the file was overwritten or created.",
    schema: z.object({
        file_path: z.string().describe("The absolute path to the file to write to."),
        content: z.string().describe("The content to write into the file.")
    }),
    func: async ({ file_path, content }) => {
        try {
            const exists = await fs.pathExists(file_path);
            await fs.outputFile(file_path, content);

            if (exists) {
                return `Successfully overwrote file: ${file_path}`;
            } else {
                return `Successfully created and wrote to new file: ${file_path}`;
            }
        } catch (error) {
            return `Error writing file: ${error.message}`;
        }
    }
});

module.exports = writeFileTool;
