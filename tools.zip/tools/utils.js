const path = require("path");

const COMMON_IGNORES = ["**/node_modules/**", "**/.git/**", "**/.DS_Store"];

function getMimeType(filePath) {
    const ext = path.extname(filePath).toLowerCase();
    const map = {
        '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg',
        '.gif': 'image/gif', '.webp': 'image/webp', '.svg': 'image/svg+xml', '.bmp': 'image/bmp',
        '.mp3': 'audio/mpeg', '.wav': 'audio/wav', '.aiff': 'audio/aiff', '.aac': 'audio/aac',
        '.ogg': 'audio/ogg', '.flac': 'audio/flac',
        '.pdf': 'application/pdf'
    };
    return map[ext] || 'application/octet-stream';
}

module.exports = { COMMON_IGNORES, getMimeType };
