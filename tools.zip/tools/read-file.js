const { DynamicStructuredTool } = require("@langchain/core/tools");
const { z } = require("zod");
const fs = require("fs-extra");
const { getMimeType } = require("./utils");

const readFileTool = new DynamicStructuredTool({
    name: "read_file",
    description: "Reads and returns the content of a specified file. Handles text, images, audio, and PDF files. For text files, it can read specific line ranges.\nOutput:\n- Text: The file content, potentially truncated.\n- Binary: An object with inlineData (mimeType and base64 data).",
    schema: z.object({
        path: z.string().describe("The absolute path to the file to read."),
        offset: z.number().optional().describe("For text files, the 0-based line number to start reading from. Requires limit to be set."),
        limit: z.number().optional().describe("For text files, the maximum number of lines to read. If omitted, reads a default maximum or the entire file.")
    }),
    func: async ({ path: filePath, offset, limit }) => {
        try {
            if (!await fs.pathExists(filePath)) {
                return `Error: File ${filePath} does not exist.`;
            }

            const mimeType = getMimeType(filePath);
            const isText = !mimeType.startsWith('image/') && !mimeType.startsWith('audio/') && mimeType !== 'application/pdf';

            if (isText) {
                const content = await fs.readFile(filePath, 'utf8');
                const lines = content.split('\n');

                let start = 0;
                let end = lines.length;

                if (offset !== undefined && limit !== undefined) {
                    start = offset;
                    end = Math.min(offset + limit, lines.length);
                } else if (limit !== undefined) {
                    end = Math.min(limit, lines.length);
                } else {
                    end = Math.min(2000, lines.length);
                }

                const truncated = (end < lines.length) || (start > 0);
                const slice = lines.slice(start, end).join('\n');

                let output = slice;
                if (truncated) {
                    output = `[File content truncated: showing lines ${start}-${end} of ${lines.length} total lines...]\n${output}`;
                }
                return output;
            } else {
                const buffer = await fs.readFile(filePath);
                const base64 = buffer.toString('base64');
                return JSON.stringify({
                    inlineData: {
                        mimeType: mimeType,
                        data: base64
                    }
                });
            }
        } catch (error) {
            return `Error reading file: ${error.message}`;
        }
    }
});

module.exports = readFileTool;
