const { DynamicStructuredTool } = require("@langchain/core/tools");
const { z } = require("zod");
const fs = require("fs-extra");

const replaceTool = new DynamicStructuredTool({
    name: "replace",
    description: "Replaces text within a file. By default, replaces a single occurrence, but can replace multiple occurrences when expected_replacements is specified.\nOutput: A success message indicating the file modification or creation.",
    schema: z.object({
        file_path: z.string().describe("The absolute path to the file to modify."),
        old_string: z.string().describe("The exact literal text to replace. Must uniquely identify the instance to change."),
        new_string: z.string().describe("The exact literal text to replace old_string with."),
        expected_replacements: z.number().optional().default(1).describe("The number of occurrences to replace. Defaults to 1.")
    }),
    func: async ({ file_path, old_string, new_string, expected_replacements = 1 }) => {
        try {
            // "If old_string is empty and file_path does not exist, creates a new file with new_string as content."
            if (!old_string) {
                if (await fs.pathExists(file_path)) {
                    return `Error: old_string is empty but file ${file_path} already exists.`;
                }
                await fs.outputFile(file_path, new_string);
                return `Created new file: ${file_path} with provided content.`;
            }

            if (!await fs.pathExists(file_path)) {
                return `Error: File ${file_path} does not exist.`;
            }

            const content = await fs.readFile(file_path, 'utf8');

            // "If one occurrence is found, it replaces it with new_string."
            // "can replace multiple occurrences when expected_replacements is specified."

            const parts = content.split(old_string);
            const occurrences = parts.length - 1;

            if (occurrences === 0) {
                return `Failed to edit, 0 occurrences found for the provided old_string in ${file_path}.`;
            }

            if (expected_replacements !== undefined && occurrences !== expected_replacements) {
                return `Failed to edit, expected ${expected_replacements} occurrences but found ${occurrences} of old_string.`;
            }

            const newContent = parts.join(new_string);
            await fs.writeFile(file_path, newContent);

            return `Successfully modified file: ${file_path} (${occurrences} replacements).`;

        } catch (error) {
            return `Error performing replace: ${error.message}`;
        }
    }
});

module.exports = replaceTool;
