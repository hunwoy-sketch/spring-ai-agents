const { DynamicStructuredTool } = require("@langchain/core/tools");
const { z } = require("zod");
const fs = require("fs-extra");
const path = require("path");
const fg = require("fast-glob");
const { COMMON_IGNORES } = require("./utils");

const searchFileContentTool = new DynamicStructuredTool({
    name: "search_file_content",
    description: "Searches for a regular expression pattern within the content of files in a specified directory. Can filter files by a glob pattern. Returns the lines containing matches, along with their file paths and line numbers.\nOutput: A formatted string of matches with file paths and line numbers.",
    schema: z.object({
        pattern: z.string().describe("The regular expression (regex) to search for (e.g., \"function\\s+myFunction\")."),
        path: z.string().optional().describe("The absolute path to the directory to search within. Defaults to the current working directory."),
        include: z.string().optional().describe("A glob pattern to filter which files are searched (e.g., \"*.js\", \"src/**/*.{ts,tsx}\"). If omitted, searches most files.")
    }),
    func: async ({ pattern, path: searchPath, include }) => {
        try {
            const cwd = searchPath || process.cwd();
            const regex = new RegExp(pattern);

            const filePattern = include || "**/*";
            const files = await fg(filePattern, {
                cwd,
                absolute: true,
                ignore: COMMON_IGNORES,
                onlyFiles: true
            });

            let out = [];

            for (const file of files) {
                try {
                    const content = await fs.readFile(file, 'utf8');
                    const lines = content.split('\n');
                    lines.forEach((line, index) => {
                        if (regex.test(line)) {
                            // "Returns a list of matching lines, each prefixed with its file path (relative to the search directory) and line number."
                            const relPath = path.relative(cwd, file);
                            out.push(`File: ${relPath}\nL${index + 1}: ${line.trim()}`);
                        }
                    });
                } catch (err) {
                    // Skip binary files or read errors
                }
            }

            if (out.length === 0) {
                return `No matches found for pattern "${pattern}" in path "${cwd}" (filter: "${include || 'none'}").`;
            }
            return `Found ${out.length} matches for pattern "${pattern}" in path "${cwd}" (filter: "${include || 'none'}"):\n---\n${out.join('\n---\n')}\n---`;
        } catch (error) {
            return `Error searching files: ${error.message}`;
        }
    }
});

module.exports = searchFileContentTool;
